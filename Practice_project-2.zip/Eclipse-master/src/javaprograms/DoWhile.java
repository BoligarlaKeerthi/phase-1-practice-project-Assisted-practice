package javaprograms;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		do
		{
			System.out.println("today is wednesday");
			i++;
		}while(i<=7);
		
		System.out.println("comes out of the loop");
	}

}
