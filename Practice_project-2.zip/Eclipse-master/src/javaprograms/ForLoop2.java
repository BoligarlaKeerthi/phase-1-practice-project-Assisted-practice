package javaprograms;

public class ForLoop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="learning java";
		int len=s1.length();
		for(int i=0;i<len;i++)
		{
			System.out.print(s1.charAt(i));
		}

	}

}
