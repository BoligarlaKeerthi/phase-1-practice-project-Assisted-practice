package javaprograms;

public class EplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a =11.34;  //convert into integer
		int b=(int)a;
		System.out.println(b);

	}

}
