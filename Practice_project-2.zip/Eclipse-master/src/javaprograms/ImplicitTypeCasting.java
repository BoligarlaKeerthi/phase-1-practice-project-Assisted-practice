package javaprograms;

public class ImplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;   //converting integer variable to double
		double b;
		b=a;
		System.out.println(b);

	}

}
