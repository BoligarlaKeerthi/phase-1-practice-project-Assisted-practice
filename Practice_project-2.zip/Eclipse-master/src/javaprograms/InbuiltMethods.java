package javaprograms;

public class InbuiltMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="selenium ";
		String s2="training";
		String s3=s1+s2;
		String s4=s1.concat(s2);
		System.out.println("concatination using + operator : " + s3);
		System.out.println("concatination using concat method : " + s4);

	}

}
