package javaprograms;

public class DatatypesDemo {

	public static void main(String[] args) { 
		int var1=1;
		double var2=7.8;
		char var3='a';
		String var4="selenium";
		System.out.println("the value of integer:"+var1);
		System.out.println("the value ofdouble:"+var2);
		System.out.println("the value of character:"+var3);
		System.out.println("the value of string:"+var4);

	}

}
