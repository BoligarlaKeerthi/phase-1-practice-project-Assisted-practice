package javaprograms;

public class AccessModifier1 {
	
	//default access modifier
	     int hours =3;
	     int mins = 47;
	 //public access modifier
	    public String name = "sonal";
		public String tool = "Selenium";
      //private access modifier   
		private int a =3;
		private int b = 47;
	//protected access modifier
		protected int x = 10;
		protected int z = 20;
		
		
		
		
}




	