package testNG;

import org.testng.annotations.Test;

public class Testng1 {
	@Test
	public void method1() {
		
	}

}
