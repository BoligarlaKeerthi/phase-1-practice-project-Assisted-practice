$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"73a1a8da-d803-440c-acfc-92d8420bfcda","feature":"Phase End project","scenario":"Star health home page test","start":1698134248549,"group":1,"content":"","tags":"","end":1698134264208,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});